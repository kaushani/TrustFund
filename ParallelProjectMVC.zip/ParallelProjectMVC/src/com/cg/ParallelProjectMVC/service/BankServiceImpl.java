package com.cg.ParallelProjectMVC.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ParallelProjectMVC.bean.Account;
import com.cg.ParallelProjectMVC.bean.Transaction;
import com.cg.ParallelProjectMVC.dao.IBankDAO;
import com.cg.ParallelProjectMVC.exception.ParallelProjectMVCException;
@Service
public class BankServiceImpl implements IBankService{

	@Autowired
	private IBankDAO dao;
	@Override
	public long addAccount(Account a) throws ParallelProjectMVCException {
		// TODO Auto-generated method stub
		return dao.addAccount(a);
	}

	@Override
	public double showBalance(long accountNumber) throws ParallelProjectMVCException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean deposit(long accountNumber, double amount) throws ParallelProjectMVCException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean withdraw(long accountNumber, double amount) throws ParallelProjectMVCException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean fundTransfer(long accountNumber, long accountNumber2, double amount)
			throws ParallelProjectMVCException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Transaction> printTransactions(long accountNumber) throws ParallelProjectMVCException {
		// TODO Auto-generated method stub
		return null;
	}

}
