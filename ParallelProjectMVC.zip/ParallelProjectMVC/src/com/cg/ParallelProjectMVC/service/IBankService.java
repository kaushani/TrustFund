package com.cg.ParallelProjectMVC.service;

import java.util.List;

import com.cg.ParallelProjectMVC.bean.Account;
import com.cg.ParallelProjectMVC.bean.Transaction;
import com.cg.ParallelProjectMVC.exception.ParallelProjectMVCException;

public interface IBankService {
	long addAccount(Account a) throws ParallelProjectMVCException;
	double showBalance(long accountNumber) throws ParallelProjectMVCException;
	boolean deposit(long accountNumber, double amount) throws ParallelProjectMVCException;
	boolean withdraw(long accountNumber, double amount) throws ParallelProjectMVCException;
	boolean fundTransfer(long accountNumber, long accountNumber2, double amount) throws ParallelProjectMVCException;
	List<Transaction> printTransactions(long accountNumber) throws ParallelProjectMVCException;
}
