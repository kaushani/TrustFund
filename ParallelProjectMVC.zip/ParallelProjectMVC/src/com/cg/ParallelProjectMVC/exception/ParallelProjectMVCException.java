package com.cg.ParallelProjectMVC.exception;

public class ParallelProjectMVCException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ParallelProjectMVCException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
