package com.cg.ParallelProjectMVC.bean;

public class Account {
	private static String bankName = "XYZ Bank";
	private String accountHolder;
	private String address;
	private long accountNumber;
	private long mobileNumber;
	private double balance;
	private String email;
		
	public static String getBankName() {
		return bankName;
	}
	public static void setBankName(String bankName) {
		Account.bankName = bankName;
	}
	public String getAccountHolder() {
		return accountHolder;
	}
	public void setAccountHolder(String accountHolder) {
		this.accountHolder = accountHolder;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Account [accountHolder=" + accountHolder + ", address=" + address
				+ ", accountNumber=" + accountNumber + ", mobileNumber=" + mobileNumber + ", balance="
				+ balance + ", email=" + email + "]";
	}
	
}
