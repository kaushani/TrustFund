package com.cg.ParallelProjectMVC.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ParallelProjectMVC.bean.Account;
import com.cg.ParallelProjectMVC.exception.ParallelProjectMVCException;
import com.cg.ParallelProjectMVC.service.BankServiceImpl;
import com.sun.accessibility.internal.resources.accessibility;

@Controller
public class bankcontroller {

	// @Autowired
//	private BankServiceImpl service;
//
//	public BankServiceImpl getService() {
//		return service;
//	}
//
//	public void setService(BankServiceImpl service) {
//		this.service = service;
//	}

	@RequestMapping("/showHome")
	public String showHome() {
		return "Home";

	}

//	@RequestMapping("/showAddAccount")
//	public ModelAndView showAccountForm() {
//		Account account = new Account();
//		return new ModelAndView("addAccount", "account", account);
//
//	}
//
//	@RequestMapping("/addAccount")
//	public ModelAndView insertAccountDetails(@ModelAttribute("account") @Valid Account account, BindingResult result) {
//		ModelAndView mv = null;
//		if (!result.hasErrors()) {
//			try {
//
//				long accountNumber = service.addAccount(account);
//				mv = new ModelAndView("success", "accountNumber", accountNumber);
//			} catch (ParallelProjectMVCException e) {
//				// TODO Auto-generated catch block
//
//			}
//
//		} else
//			mv = new ModelAndView("addAccount", "account", account);
//		return mv;
//
//	}
}
