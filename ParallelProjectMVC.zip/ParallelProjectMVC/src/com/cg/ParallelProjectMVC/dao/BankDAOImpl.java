package com.cg.ParallelProjectMVC.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.ParallelProjectMVC.bean.Account;
import com.cg.ParallelProjectMVC.bean.Transaction;
import com.cg.ParallelProjectMVC.exception.ParallelProjectMVCException;

@Repository
public class BankDAOImpl implements IBankDAO{

	@PersistenceContext
	private EntityManager entityManager;
	@Override
	public long addAccount(Account a) throws ParallelProjectMVCException {
		// TODO Auto-generated method stub
		entityManager.persist(a);
		entityManager.flush();
		return a.getAccountNumber();
	}

	@Override
	public double showBalance(long accountNumber) throws ParallelProjectMVCException {
		// TODO Auto-generated method stub
		//TypedQuery<Account> query = entityManager.createQuery("SELECT balance FROM Account where accountNumber="+accountNumber, Account.class);
		Account a=entityManager.find(Account.class,accountNumber);
		return a.getBalance();
	}

	@Override
	public boolean deposit(long accountNumber, double amount) throws ParallelProjectMVCException {
		// TODO Auto-generated method stub
		
		return false;
	}

	@Override
	public boolean withdraw(long accountNumber, double amount) throws ParallelProjectMVCException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean fundTransfer(long accountNumber, long accountNumber2, double amount)
			throws ParallelProjectMVCException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Transaction> printTransactions(long accountNumber) throws ParallelProjectMVCException {
		// TODO Auto-generated method stub
		return null;
	}

}
